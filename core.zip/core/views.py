from django.shortcuts import render, HttpResponse


# Create your views here.

def homepage(request):
    return HttpResponse('hi')


def about(request):
    return HttpResponse('Найдите работу или работника мечты')


def contacts(request):
    return HttpResponse(f'Phone: +996777123456 <br> Email: office@handhunter.kg')

